﻿using battelships;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace battelships
{
    using System;

    [Serializable]
    public abstract class Ships
    {
        protected float x;
        protected float y;
        protected string type;
        protected  int crew;
        protected  int cannons;
        
        
        
        
      
        public float X
        {
            get{ return x;}
            set{x = value;}
        }

        public float Y
        { 
            get {return y;}
            set {y = value;}
        }
        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        public int Crew
        { get { return crew; }
           set { crew = value; }
        }

        public int Cannons
        { get { return cannons; }
           set { crew = value; }
        }
        
        public abstract int Fight();
        public abstract void Draw(Graphics g);
        public abstract bool IsInside(int xP, int yP);
        ~Ships()
        {

        }

        
        
    }
    [Serializable]

    public class battelship : Ships
    {
        protected int velocity;
        protected float width;
        protected float height;

        public battelship()
          : this(10, 10, 10, 20, 0, 0) { }
        
        public battelship(float xVal, float yVal, float width, float height ,int crew1,int cannons1)
        {
            X = xVal;
            Y = yVal;
            this.velocity = 5;
            Width = width;
            Height = height;
            Crew = crew1;
            Cannons = cannons1;

            
        }

        //public battelship(int crew1, int cannons1) : base()
        //{
        //    x = 50;
        //    y = 50;
        //    width = 50;
        //    height = 60;
        //    crew = crew1;
        //    cannons = cannons1;
        //    type = "battleship";
        //    velocity = 5;

        public int Velocity
        {
            get
            {
                return velocity;
            }
            set
            {
                velocity = value;
            }
        }
        //}
        public float Height
        {
            get
            {
                return height;
            }
            set
            {
                height = value;
            }
        }

        public float Width
        {
            get
            {
                return width;
            }
            set
            {
                width = value;
            }
        }
        public override int Fight()
        {
            return cannons * crew * velocity;
        }
        public override void Draw(Graphics g)
        {
            SolidBrush br = new SolidBrush(Color.Red);
            Pen pen = new Pen(Color.Cyan, 2);
            g.FillRectangle(br, X - width / 2, Y - height / 2, width, height);
            g.DrawRectangle(pen, X - width / 2, Y - height / 2, width, height);
        }
        public override bool IsInside(int xP, int yP)
        {
            return Math.Abs(xP - X) <= width / 2 && Math.Abs(yP - Y) <= height / 2;
        }
        ~battelship()
        {

        }




    }
    [Serializable]
    public class Submarine : Ships
    {
        protected int dept;
        protected float radius;
        public Submarine()
          : this(10, 10, 50,0, 0) { }

        public Submarine( float xVal,float yVal, float radius, int crew1,int cannons1)
        {
            X = xVal;
            Y = yVal;
            this.dept = 5;
            Radius = radius;
            Crew = crew1;
            Cannons = cannons1;
            
        }

        //public Submarine(int crew1, int cannons1)
        //{
        //    x = 50;
        //    y = 50;
        //    radius = 25;
        //    crew = crew1;
        //    cannons = cannons1;
        //    type = "submarine";
        //    dept = 5;
        //}
         public float Radius
        {
        get
        {
            return radius;
        }
        set
        {
            radius = value;
        }
        }

    public override int Fight()
        {
            return crew*cannons*dept ;
        }

        public override bool IsInside(int xP, int yP)
        {
        return Math.Sqrt((xP - X) * (xP - X) + (yP - Y) * (yP - Y)) < radius;
        //if (x > 15 && x < 1204)
        //    if (y > 15 && y < 831)
        //        return true;
        //return false;
    }
         public override void Draw(Graphics g)
          {
           SolidBrush br = new SolidBrush(Color.LimeGreen);
           Pen pen = new Pen(Color.Cyan, 2);
           g.FillEllipse(br, X - radius, Y - radius, 2 * radius, 2 * radius);
           g.DrawEllipse(pen, X - radius, Y - radius, 2 * radius, 2 * radius);
        }
        ~Submarine()
        {

        }

}
    [Serializable]
    public class Fireship : battelship
    {
        public Fireship()
          : this(10, 10, 10, 20, 0, 0) { }
        public Fireship(float xVal, float yVal, float wVal, float hVal, int crew1, int cannons1)
        {
            X = xVal;
            Y = yVal;
            Velocity = 8;
            Width = wVal;
            Height = hVal;
            Crew = crew1;
            Cannons = cannons1;
        }
        //public Fireship(int crew1, int cannons1) 
        //{
        //    x = 30;
        //    y = 30;
        //    width = 30;
        //    height = 40;
        //    crew = crew1;
        //    cannons = cannons1;
        //    type = "fireship";
        //    velocity = 5;
        //}
        public override int Fight()
        {
            return cannons * crew * velocity;
        }

        public override void Draw(Graphics g)
        {
            SolidBrush br = new SolidBrush(Color.Orange);
            Pen pen = new Pen(Color.Cyan, 2);
            g.FillRectangle(br, X - width / 2, Y - height / 2, width, height);
            g.DrawRectangle(pen, X - width / 2, Y - height / 2, width, height);
        }
        public override bool IsInside(int xP, int yP)
        {
            return Math.Abs(xP - X) <= width / 2 && Math.Abs(yP - Y) <= height / 2;
        }

        ~Fireship()
        {
        }

    }
    [Serializable]
    public class ManOwar : battelship
{

        public ManOwar()
          : this(10, 10, 10, 20, 0, 0) { }
        public ManOwar(float xVal, float yVal, float wVal, float hVal, int crew1, int cannons1)
        {
            X = xVal;
            Y = yVal;
            Velocity = 30;
            Width = wVal;
            Height = hVal;
            Crew = crew1;
            Cannons = cannons1;
        }
        //public ManOwar(int crew1,int cannons1):base(crew1,cannons1)
        //{

        //    x = 100;
        //    y = 100;
        //    width = 100;
        //    height = 200;   
        //    crew = crew1;
        //    cannons = cannons1;
        //    velocity = 20;
        //    type = "manOwar";
        //}
        public override int Fight()
        {
            return (crew * cannons * base.velocity) + velocity;
        }

        public override void Draw(Graphics g)
        {
            SolidBrush br = new SolidBrush(Color.Blue);
            Pen pen = new Pen(Color.Cyan, 2);
            g.FillRectangle(br, X - width / 2, Y - height / 2, width, height);
            g.DrawRectangle(pen, X - width / 2, Y - height / 2, width, height);
        }
        public override bool IsInside(int xP, int yP)
        {
            return Math.Abs(xP - X) <= width / 2 && Math.Abs(yP - Y) <= height / 2;
        }
        ~ManOwar() { }
    }
}

[Serializable]
public class ShipsList
{
    protected SortedList shipsList;

    // public int NextIndex { get; private set; }

    public ShipsList()
    {
        shipsList = new SortedList();
    }
    public int LastIndex
    {
        get
        {
            return shipsList.Count;
        }
        //!!!
        // !! there is no set !!
    }
    public Ships this[int index]
    {
        get
        {
            if (index >= shipsList.Count)
                return (Ships)null;
            //SortedList internal method
            return (Ships)shipsList.GetByIndex(index);
        }
        set
        {
            if (index <= shipsList.Count)
                shipsList[index] = value;
        }
    }
    public void DrawAll(Graphics g)
    {
        // Ships prev, cur;
        //for (int i = 1; i < shipsList.Count; i++)
        //{
        //    prev = (Ships)shipsList[i - 1];
        //    cur = (Ships)shipsList[i];
        //    //g.DrawLine(Pens.Yellow, prev.X, prev.Y, cur.X, cur.Y);

        // ((Ships)shipsList[i]).Draw(g);

        for (int i = 0; i < shipsList.Count; i++)
            ((Ships)shipsList[i]).Draw(g);
    }
    public void Remove(int element)
    {
        if (element >= 0 && element < shipsList.Count)
        {
            for (int i = element; i < shipsList.Count - 1; i++)
                shipsList[i] = shipsList[i + 1];
            shipsList.RemoveAt(shipsList.Count - 1);
        }

    }



}











