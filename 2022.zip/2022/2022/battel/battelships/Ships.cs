﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battelships
{
    class Ships
    {
        float x;
        float y;
        string type;
        public
            abstract int Fight()
        {  return -1;  }
        
        public float X
        {
            get
            {
                return x;
            }
            set
            {
                x = value;
            }
        }

        public float Y
        {
            get
            {
                return y;
            }
            set
            {
                y = value;
            }
        }
        public string Type
        {
            get { return type; }
            set { type = value; }
        }
        public Ships()
        {
            x = 0;
            y = 0;
            type = "ship";
        }
        public ~Ships();
    }
    class battelships : Ships
    {
        int crew;
        int cannons;
        public int Crew
        {
            get { return crew; }
            set { crew =  }
        }
        public int Cannons
        {
            get { return cannons; }
            set { cannons = }
        }
        public battelships()
        {
            cannons = 0;
            crew = 0;
            Type = "battelships";
        }
        public battelships(int x, int y);
        {

        }
    }
    class submarine : Ships
    {
        int crew;
        int cannons;
        int power;
    }
    class fireship : battelships
    {
        int power;
    }
    class manOwar : battelships
    {
        int power;
    }
}
