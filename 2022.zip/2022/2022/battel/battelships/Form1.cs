﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Resources;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace battelships
{
    public partial class SeaFighter : Form
    {
        //List<Ships> shiplist = new List<Ships>();
       // List<PictureBox> piclist = new List<PictureBox>();

       // int curIndex = -1;


        //private object shipsSave;
        //private object openFileDialog1;

        public SeaFighter()
        {

            InitializeComponent();


            ////Init_Pictures();
            //Image picbigship = Image.FromFile(@"C:\Users\Gil\Desktop\2022\battel\battelships\Properties\IMG_2390.jpeg");
            //Image picfireship = Image.FromFile(@"C:\Users\Gil\Desktop\2022\battel\battelships\Properties\IMG_2392.jpeg");
            //Image picsub = Image.FromFile(@"C:\Users\Gil\Desktop\2022\battel\battelships\Properties\IMG_2391.jpeg");
            //pictureBox2.Image = picbigship;
            //pictureBox3.Image = picfireship;
            //pictureBox4.Image = picsub;

            //pictureBox2.Visible = false;
            //pictureBox3.Visible = false;// sub
            //pictureBox4.Visible = false;// sub
            ////pictureBox5.Visible = false;//fire
            ////pictureBox6.Visible = false;//fire
            ////pictureBox7.Visible = false;//fire
            ////pictureBox8.Visible = false;//man
            ////pictureBox9.Visible = false;//man
            comboBoxCrew.Enabled = false;
            comboBoxCannons.Enabled = false;
            //buttonFight.Enabled = false;
            //buttonNew.Enabled = false;
            ////comboBox1.Visible = false;
            ////label4.Visible = false;
            //// shipsList = new ShipsList();
        }
        ShipsList pts = new ShipsList();  
        int curIndex = -1;


        private void comboBoxCrew_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(comboBoxCrew.Text.Length) > 0)
            {
                comboBoxCannons.Enabled = true;
            }
        }
        private void comboBoxCannons_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (Convert.ToInt32(comboBoxCannons.Text.Length) > 0)
            {
                buttonFight.Enabled = true;
                //buttonNew.Enabled = true;
            }

        }
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            
            curIndex = -1;
            for (int i = 0; i < pts.LastIndex; i++)
            {
                if (pts[i].IsInside(e.X, e.Y))
                {
                    curIndex = i;
                    string s = e.Button.ToString();
                    if (s == "Right") //if Right button pressed - Remove
                    {
                        //
                        pts.Remove(curIndex);
                        curIndex = -1;
                        pictureBox1.Invalidate();
                        return;
                    }
                    break;
                }
            }
            if (curIndex < 0)
            {
                if (comboBoxType.Text.Length > 0)
                {
                    switch (comboBoxType.Text)
                    {
                        case "Battelship":
                            if ((comboBoxCrew.Text.Length)> 0 && (comboBoxCannons.Text.Length) > 0)
                        {
                                if (Convert.ToInt32(comboBoxCrew.Text) >= 15)
                                    pts[pts.LastIndex] = new ManOwar(e.X, e.Y, Convert.ToInt32(comboBoxCrew.Text), Convert.ToInt32(comboBoxCannons.Text), Convert.ToInt32(comboBoxCrew.Text), Convert.ToInt32(comboBoxCannons.Text));

                                else
                                    pts[pts.LastIndex] = new Fireship(e.X, e.Y, Convert.ToInt32(comboBoxCrew.Text), Convert.ToInt32(comboBoxCannons.Text), Convert.ToInt32(comboBoxCrew.Text), Convert.ToInt32(comboBoxCannons.Text));
                            }
                        else
                                MessageBox.Show("Add more details");
                            break;
                        case "Submarine":
                            if ((comboBoxCrew.Text.Length) > 0 && (comboBoxCannons.Text.Length) > 0)
                                pts[pts.LastIndex] = new Submarine(e.X, e.Y, Convert.ToInt32(comboBoxCrew.Text), Convert.ToInt32(comboBoxCrew.Text), Convert.ToInt32(comboBoxCannons.Text));
                            else
                                MessageBox.Show("Add more details");
                            break;
                    }
                }
                else
                    MessageBox.Show("Add more details");
                curIndex = pts.LastIndex - 1;
                pictureBox1.Invalidate();
            }
        }
        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (curIndex >= 0)
            {
                Ships c = (Ships)pts[curIndex];
                if (e.X > 8 && e.X < 610 && e.Y > 8 && e.Y < 440)
                {
                    c.X = e.X;
                    c.Y = e.Y;
                }
                pictureBox1.Invalidate();
            }

        }
        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            curIndex = -1;
        }
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            pts.DrawAll(g);

        }



        //private void buttonNew_Click(object sender, EventArgs e)
        //{
        //    //if (shiplist.Count == 8)
        //    //{
        //    //    MessageBox.Show("you have attained the nice number of ships, now press fight!");

        //    //}



        //    if (comboBoxCrew == null || comboBoxCannons == null)
        //    {
        //        MessageBox.Show("you must fill all the details");
        //    }


        //    else
        //    {
        //        int crew = Convert.ToInt32(comboBoxCrew.Text), cannons = Convert.ToInt32(comboBoxCannons.Text);
        //        if (comboBoxType.Text == "Battelship")
        //        {

        //            if (Convert.ToInt32(comboBoxCrew.Text) >= 15)
        //            {
        //                ManOwar b = new ManOwar(crew, cannons);
        //                shiplist.Add(b);
        //                piclist.Add(pictureBox2);
        //                piclist.Last().Parent = pictureBox1;
        //                Point point = new Point(b.X, b.Y);
        //                pictureBox1.Refresh();
        //                using (Graphics g = Graphics.FromImage(pictureBox1.Image))
        //                {
        //                    g.DrawImage(piclist.Last().Image, point);
        //                    g.Save();
        //                    pictureBox1.Refresh();
        //                }





        //            }
        //            else
        //            {
        //                Fireship c = new Fireship(crew, cannons);

        //                shiplist.Add(c);
        //                piclist.Add(pictureBox4);
        //                piclist.Last().Parent = pictureBox1;
        //                Point point = new Point(c.X, c.Y);
        //               // piclist.Last().Location = point;
        //                pictureBox1.Refresh();
        //                using (Graphics g = Graphics.FromImage(pictureBox1.Image))
        //                {
        //                    g.DrawImage(pictureBox4.Image, point);
        //                    g.Save();
        //                    pictureBox1.Refresh();
        //                }


        //            }
        //        }
        //        else if (comboBoxType.Text == "Submarine")
        //        {
        //            Submarine d = new Submarine(crew, cannons);

        //            shiplist.Add(d);
        //            piclist.Add(pictureBox3);
        //            piclist.Last().Parent = pictureBox1;
        //            Point point = new Point(d.X, d.Y);
        //            piclist.Last().Location = point;
        //            pictureBox1.Refresh();
        //            using (Graphics g = Graphics.FromImage(pictureBox1.Image))
        //            {
        //                g.DrawImage(pictureBox3.Image,point);
        //                g.Save();
        //                pictureBox1.Refresh();
        //            }
        //        }


        //    }

        //}

        private void buttonSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();// + "..\\myModels";
            saveFileDialog1.Filter = "model files (*.mdl)|*.mdl|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                IFormatter formatter = new BinaryFormatter();
                using (Stream stream = new FileStream(saveFileDialog1.FileName, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    //!!!!
                    formatter.Serialize(stream, pts);
                }
            }
        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();// + "..\\myModels";
            openFileDialog1.Filter = "model files (*.mdl)|*.mdl|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Stream stream = File.Open(openFileDialog1.FileName, FileMode.Open);
                var binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                //!!!!
                pts = (ShipsList)binaryFormatter.Deserialize(stream);
                pictureBox1.Invalidate();
            }
        }


        private void comboBoxType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxType.Text.Length > 0)
            {
                comboBoxCrew.Enabled = true;
            }
            //if (comboBoxType.Text== "Submarine")
            //{
            //    comboBox1.Visible = true;
            //    label4.Visible = true;
            //}
            //else a pop up message will show
        }

        private void buttonFight_Click(object sender, EventArgs e)
        {

            int i, indexofweak = 0;
            if (pts.LastIndex == 1)
            {
                MessageBox.Show("ship cannont fight against itself");
            }
            else if (pts.LastIndex == 0)
                MessageBox.Show("you need to fill up the sea");

            else if (pts.LastIndex > 1)
            {
                Ships s = pts[0];
                for (i = 1; i < pts.LastIndex; i++)
                {
                    if (s.Fight() > pts[i].Fight())
                    {
                        s = pts[i];
                        indexofweak = i;

                        

                    }
                   
                }
                pts.Remove(indexofweak);
                curIndex = - 1;
                pictureBox1.Invalidate();
            }

            //                    if( minimum.Fight()>shipsList[i].Fight())
            //                {
            //                    minimum = shipsList[i];  
            //                }
            //            }



            //private void 4_Click(object sender, EventArgs e)
            //{

            //}

            //private void label4_Click(object sender, EventArgs e)
            //{

            //}
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        
    }

        


        
        
        

        
       
 }



        
        
